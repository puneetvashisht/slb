package com.slb.workoutservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
